1) The raw dataset (wdbc.data;The same dataset also available at UCI repository). Notified, after attain the raw data, the author then change the class attribute to last column and in fuzzification folder undergo fuzzification process where each attributes
 would respectively produced in fuzzy sets value(low,medium,high) exception radius standard error (radiusnucB.ipynb) and worst radius(radiusnucC.ipynb)
based on FUZZYDBD using ipynb(python code)
2) The position of the attributes in the dataset follows the position in the manuscript paper where the last column
 present the class.
3)All the attributes being fuzzified and relocated in excel file where replacement of highest linguistic variable value chosen
4)The highest linguistic variable for all attributes conncatanate to one single file.
5)The position of the instances reshuffle when kfold in FID3 folder (id310fold.py)
6) Classification process started (use python: pycharm/spyder)
7)The results generated using kfoldcross validation

**for further info: check Execution_instruction
#to print result of id310fold.py in text formation
- pycharm is recommended; spyder also can be use but it may arise warning when print the result in text form (but for faster run, use spyder)
-please just choose one whether to print in txt format(ex: result1.txt) or print in the software prompt 